let funnelChart;
let currentEditingNodeId = null, allNodes = [];
let isDraggingNode = false, isPanning = false;
let dragNode = null, dragOffset = { x: 0, y: 0 };
let canvasOffset = { x: 0, y: 0 }, panStart = { x: 0, y: 0 }, zoom = 1;

async function updateDashboard() {
    try {
        const response = await fetch('/api/stats');
        const data = await response.json();
        document.getElementById('revenue').innerText = `${data.revenue.toLocaleString()}₽`;
        document.getElementById('total_users').innerText = data.total_users;
        document.getElementById('conversion').innerText = `${data.conversion_rate || 0}%`;
        
        const stages = [
            { label: 'Starts', val: data.events.view_node_entry || 0 },
            { label: 'Engagement', val: data.events.view_node_value || 0 },
            { label: 'Leads', val: data.events.view_node_contact || 0 },
            { label: 'Sales', val: data.events.view_node_success || 0 }
        ];

        const container = document.getElementById('visual-funnel');
        if (container) {
            container.innerHTML = '';
            const maxVal = Math.max(...stages.map(s => s.val)) || 1;
            stages.forEach((s, i) => {
                const width = (s.val / maxVal) * 100;
                container.innerHTML += `<div class="funnel-stage"><div class="funnel-bar" style="width: ${width}%"></div><div class="stage-info"><div>${s.label}</div></div><div class="stage-val">${s.val}</div></div>`;
                if (i < stages.length - 1) { const drop = s.val ? Math.round((stages[i+1].val / s.val) * 100) : 0; container.innerHTML += `<div class="funnel-sep" data-drop="${drop}% CR"></div>`; }
            });

            const ctx = document.getElementById('funnelChart').getContext('2d');
            const gradient = ctx.createLinearGradient(0, 0, 0, 400);
            gradient.addColorStop(0, 'rgba(167, 139, 250, 0.2)');
            gradient.addColorStop(1, 'rgba(167, 139, 250, 0)');

            if (funnelChart) {
                funnelChart.data.labels = stages.map(s => s.label);
                funnelChart.data.datasets[0].data = stages.map(s => s.val);
                funnelChart.update('none');
            } else {
                funnelChart = new Chart(ctx, { 
                    type: 'line', 
                    data: { 
                        labels: stages.map(s => s.label), 
                        datasets: [{ 
                            data: stages.map(s => s.val), 
                            borderColor: '#a78bfa', 
                            borderWidth: 3, 
                            fill: true, 
                            backgroundColor: gradient,
                            tension: 0.4,
                            pointRadius: 4,
                            pointBackgroundColor: '#a78bfa',
                            pointBorderColor: '#000',
                            pointBorderWidth: 2,
                            pointHoverRadius: 7
                        }] 
                    }, 
                    options: { 
                        responsive: true, maintainAspectRatio: false, 
                        scales: { 
                            x: { 
                                grid: { color: 'rgba(255,255,255,0.05)', drawBorder: false },
                                ticks: { color: 'rgba(255,255,255,0.4)', font: { size: 10 } }
                            }, 
                            y: { 
                                beginAtZero: true,
                                grid: { color: 'rgba(255,255,255,0.05)', drawBorder: false },
                                ticks: { 
                                    color: 'rgba(255,255,255,0.4)', 
                                    font: { size: 10 },
                                    padding: 10,
                                    callback: function(value) {
                                        if (value >= 1000) return (value / 1000).toFixed(1) + 'k';
                                        return value;
                                    }
                                }
                            } 
                        }, 
                        plugins: { 
                            legend: { display: false },
                            tooltip: {
                                backgroundColor: '#131316',
                                titleColor: '#fff',
                                bodyColor: '#a78bfa',
                                borderColor: 'rgba(255,255,255,0.1)',
                                borderWidth: 1,
                                padding: 12,
                                displayColors: false,
                                callbacks: {
                                    label: function(context) {
                                        return `Count: ${context.parsed.y}`;
                                    }
                                }
                            }
                        } 
                    } 
                });
            }
        }
    } catch (e) { console.error(e); }
}

function showTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    const target = document.getElementById(`${tabId}-tab`);
    if(target) target.classList.add('active');
    
    document.querySelectorAll('.tab-btn').forEach(btn => {
        if(btn.innerText.toLowerCase().includes(tabId)) btn.classList.add('active');
    });

    if (tabId === 'constructor') loadNodes();
    if (tabId === 'overview') updateDashboard();
    if (tabId === 'crm') loadUsers();
    if (tabId === 'planner') loadPlannerQueue();
}

async function loadUsers() {
    const r = await fetch('/api/users');
    const users = await r.json();
    const tb = document.querySelector('#usersTable tbody');
    if (!tb) return;
    tb.innerHTML = '';
    users.forEach(u => {
        tb.innerHTML += `<tr><td>@${u.username || u.telegram_id}</td><td>${u.email || '—'}</td><td><span class="badge ${u.is_paid ? 'paid' : 'pending'}">${u.is_paid ? 'PAID' : 'FREE'}</span></td><td><button class="dm-btn">DM</button></td></tr>`;
    });
}

async function loadPlannerQueue() {
    const r = await fetch('/api/planner/list');
    const jobs = await r.json();
    const list = document.getElementById('plan-queue');
    if (!list) return;
    list.innerHTML = jobs.length ? '' : '<div style="padding:20px; color:var(--text-muted)">Queue empty</div>';
    jobs.forEach(j => {
        list.innerHTML += `<div class="plan-item"><div><strong>Target: ${j.filter_type}</strong><p>${j.message.substring(0,40)}...</p></div></div>`;
    });
}

// --- CONSTRUCTOR CORE ---
async function loadNodes() {
    try {
        const response = await fetch('/api/nodes');
        allNodes = await response.json();
        renderCanvas();
        initCanvasControls();
    } catch(e) { console.error("Load failed", e); }
}

function renderCanvas() {
    const nodesLayer = document.getElementById('flow-nodes');
    if(!nodesLayer) return;
    nodesLayer.innerHTML = '';
    
    allNodes.forEach(node => {
        const div = document.createElement('div');
        div.className = `flow-node ${currentEditingNodeId === node.id ? 'active' : ''}`;
        div.id = `node-${node.id}`;
        div.style.left = `${node.x}px`;
        div.style.top = `${node.y}px`;
        div.style.position = 'absolute';
        
        div.innerHTML = `
            <div class="node-input-port" onmouseup="onDropPort(event, '${node.id}')"></div>
            <div class="node-header">
                <span class="node-id">#${node.id}</span>
            </div>
            <div class="node-body">
                <div class="node-title">${node.title || 'unnamed'}</div>
                <div class="node-btns">
                    ${(node.buttons || []).map((b, i) => `
                        <div class="node-btn" id="btn-${node.id}-${i}">
                            <span>${b.text}</span>
                            <div class="node-output-port" onmousedown="onStartConnect(event, '${node.id}', ${i})"></div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        
        div.onmousedown = (e) => {
            if (e.target.closest('.node-output-port') || e.target.closest('.node-input-port')) return;
            startDraggingNode(e, node);
        };
        div.onclick = (e) => { if(!isDraggingNode) editNode(node.id); };
        nodesLayer.appendChild(div);
    });
    try { drawConnections(); } catch(e) {}
}

function drawConnections() {
    const s = document.getElementById('flow-svg'); if (!s) return;
    const canvas = document.getElementById('flow-canvas');
    const cr = canvas.getBoundingClientRect();
    
    // Maintain defs (arrows)
    const defs = s.querySelector('defs');
    s.innerHTML = '';
    if(defs) s.appendChild(defs);
    
    allNodes.forEach(node => {
        (node.buttons || []).forEach((btn, i) => {
            if (btn.next_node) {
                const targetNode = allNodes.find(n => n.id === btn.next_node);
                if (targetNode) {
                    const port = document.querySelector(`#btn-${node.id}-${i} .node-output-port`);
                    const targetEl = document.getElementById(`node-${targetNode.id}`);
                    if (port && targetEl) {
                        const pr = port.getBoundingClientRect();
                        const tr = targetEl.querySelector('.node-input-port').getBoundingClientRect();
                        
                        // Corrected: Subtract canvas client rect and DIVIDE by zoom 
                        // to get coordinates in the 10000x10000 space
                        const x1 = (pr.left + pr.width/2 - cr.left) / zoom;
                        const y1 = (pr.top + pr.height/2 - cr.top) / zoom;
                        const x2 = (tr.left + tr.width/2 - cr.left) / zoom;
                        const y2 = (tr.top + tr.height/2 - cr.top) / zoom;
                        
                        const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
                        // Smoother Bezier curve
                        const dx = Math.abs(x1 - x2) / 2;
                        path.setAttribute("d", `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`);
                        path.setAttribute("stroke", "rgba(255, 255, 255, 0.3)");
                        path.setAttribute("stroke-width", "2");
                        path.setAttribute("fill", "none");
                        path.setAttribute("marker-end", "url(#arrowhead)");
                        s.appendChild(path);
                    }
                }
            }
        });
    });
}

function initCanvasControls() {
    const tab = document.getElementById('constructor-tab');
    const canvas = document.getElementById('flow-canvas');
    if (!tab || !canvas) return;
    
    tab.onmousedown = (e) => {
        if (e.target.closest('.flow-node') || e.target.closest('.side-panel')) return;
        isPanning = true;
        panStart.x = e.clientX - canvasOffset.x;
        panStart.y = e.clientY - canvasOffset.y;
    };
    window.onmousemove = (e) => {
        if (isPanning) {
            canvasOffset.x = e.clientX - panStart.x;
            canvasOffset.y = e.clientY - panStart.y;
            canvas.style.transform = `translate(${canvasOffset.x}px, ${canvasOffset.y}px) scale(${zoom})`;
        }
    };
    window.onmouseup = () => { isPanning = false; };
}

function startDraggingNode(e, node) {
    isDraggingNode = true;
    const el = document.getElementById(`node-${node.id}`);
    const canvas = document.getElementById('flow-canvas');
    const cr = canvas.getBoundingClientRect();
    const rect = el.getBoundingClientRect();
    
    dragOffset.x = (e.clientX - rect.left) / zoom;
    dragOffset.y = (e.clientY - rect.top) / zoom;
    
    let ticking = false;
    const onMove = (me) => {
        if (!ticking) {
            window.requestAnimationFrame(() => {
                node.x = (me.clientX - cr.left)/zoom - dragOffset.x;
                node.y = (me.clientY - cr.top)/zoom - dragOffset.y;
                el.style.left = `${node.x}px`;
                el.style.top = `${node.y}px`;
                drawConnections();
                ticking = false;
            });
            ticking = true;
        }
    };
    const onUp = async () => {
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
        await fetch(`/api/nodes/${node.id}/position`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ x: Math.round(node.x), y: Math.round(node.y)})
        });
        setTimeout(() => isDraggingNode = false, 100);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
}

function editNode(id) {
    currentEditingNodeId = id;
    const node = allNodes.find(n => n.id === id);
    if (!node) return;
    
    document.getElementById('edit-node-id').innerText = `@${node.id}`;
    document.getElementById('edit-node-title').value = node.title || '';
    document.getElementById('edit-node-content').value = node.content || '';
    
    const list = document.getElementById('buttons-list');
    list.innerHTML = '';
    (node.buttons || []).forEach((b, i) => {
        list.innerHTML += `
            <div style="background:rgba(255,255,255,0.03); border:1px solid var(--border); padding:16px; border-radius:12px; margin-bottom:12px;">
                <div class="form-group">
                    <label style="font-size:9px;">Button Text</label>
                    <input type="text" value="${b.text}" onchange="updateBtnText(${i}, this.value)" style="width:100%; background:none; border:none; color:white; border-bottom:1px solid var(--border); padding:8px 0;">
                </div>
                <div class="form-group" style="margin-top:12px;">
                    <label style="font-size:9px;">Next Block</label>
                    <select onchange="updateBtnLink(${i}, this.value)" style="width:100%; background:#000; color:white; border:1px solid var(--border); border-radius:8px; padding:8px;">
                        <option value="">None</option>
                        ${allNodes.map(n => `<option value="${n.id}" ${b.next_node === n.id ? 'selected' : ''}>#${n.id} ${n.title}</option>`).join('')}
                    </select>
                </div>
                <button onclick="removeBtn(${i})" style="margin-top:12px; background:none; border:none; color:#ff4444; font-size:10px; cursor:pointer;">✕ Remove Button</button>
            </div>
        `;
    });
    
    // Populate Follow-up fields
    document.getElementById('edit-follow-up-delay').value = node.follow_up_delay || '';
    const fuSelect = document.getElementById('edit-follow-up-node');
    fuSelect.innerHTML = '<option value="">Disabled</option>' + 
        allNodes.map(n => `<option value="${n.id}" ${node.follow_up_node === n.id ? 'selected' : ''}>#${n.id} ${n.title}</option>`).join('');
    
    document.getElementById('node-editor').style.display = 'block';
    renderCanvas();
}

function updateBtnText(idx, val) {
    const node = allNodes.find(n => n.id === currentEditingNodeId);
    if (node) node.buttons[idx].text = val;
}

function updateBtnLink(idx, val) {
    const node = allNodes.find(n => n.id === currentEditingNodeId);
    if (node) {
        node.buttons[idx].next_node = val || null;
        renderCanvas();
    }
}

function removeBtn(idx) {
    const node = allNodes.find(n => n.id === currentEditingNodeId);
    if (node) {
        node.buttons.splice(idx, 1);
        editNode(currentEditingNodeId);
    }
}

function addButton() {
    const node = allNodes.find(n => n.id === currentEditingNodeId);
    if (node) {
        if (!node.buttons) node.buttons = [];
        node.buttons.push({ text: "New Button", next_node: null });
        editNode(currentEditingNodeId);
    }
}

// Drag & Drop Connections Logic
window.onStartConnect = (e, nodeId, btnIndex) => {
    e.stopPropagation();
    connectingFrom = { nodeId, btnIndex };
    window.addEventListener('mousemove', onDragConnection);
    window.addEventListener('mouseup', onStopConnect);
};

function onDragConnection(e) {
    if (!connectingFrom) return;
    const s = document.getElementById('flow-svg');
    const cr = document.getElementById('flow-canvas').getBoundingClientRect();
    const port = document.querySelector(`#btn-${connectingFrom.nodeId}-${connectingFrom.btnIndex} .node-output-port`);
    if (!port) return;
    
    const pr = port.getBoundingClientRect();
    const x1 = (pr.left + pr.width/2 - cr.left)/zoom, y1 = (pr.top + pr.height/2 - cr.top)/zoom;
    const x2 = (e.clientX - cr.left)/zoom, y2 = (e.clientY - cr.top)/zoom;
    
    let line = document.getElementById('drag-line');
    if(!line) {
        line = document.createElementNS("http://www.w3.org/2000/svg", "path");
        line.id = 'drag-line';
        line.setAttribute("stroke", "var(--warning)");
        line.setAttribute("stroke-width", "2");
        line.setAttribute("fill", "none");
        line.setAttribute("stroke-dasharray", "5,5");
        s.appendChild(line);
    }
    line.setAttribute("d", `M ${x1} ${y1} C ${x1 + 50} ${y1}, ${x2 - 50} ${y2}, ${x2} ${y2}`);
}

async function onDropPort(e, targetNodeId) {
    if (connectingFrom && connectingFrom.nodeId !== targetNodeId) {
        console.log("Connecting", connectingFrom.nodeId, "to", targetNodeId);
        const node = allNodes.find(n => n.id === connectingFrom.nodeId);
        if (node && node.buttons[connectingFrom.btnIndex]) {
            node.buttons[connectingFrom.btnIndex].next_node = targetNodeId;
            await fetch(`/api/nodes/${node.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(node)
            });
            connectingFrom = null; // Clear before reload
            loadNodes();
        }
    }
}

function onStopConnect() {
    // Small delay to allow onDropPort to fire first
    setTimeout(() => {
        connectingFrom = null;
        const line = document.getElementById('drag-line');
        if(line) line.remove();
        window.removeEventListener('mousemove', onDragConnection);
        window.removeEventListener('mouseup', onStopConnect);
    }, 50);
}

function closeEditor() {
    document.getElementById('node-editor').style.display = 'none';
    currentEditingNodeId = null;
    renderCanvas();
}

async function saveNode() {
    const node = allNodes.find(n => n.id === currentEditingNodeId);
    if (!node) return;
    node.title = document.getElementById('edit-node-title').value;
    node.content = document.getElementById('edit-node-content').value;
    node.follow_up_delay = parseInt(document.getElementById('edit-follow-up-delay').value) || null;
    node.follow_up_node = document.getElementById('edit-follow-up-node').value || null;

    await fetch(`/api/nodes/${node.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(node)
    });
    closeEditor();
    loadNodes();
}

async function createNewNode() {
    const id = prompt("Node ID (unique):");
    if (!id) return;
    await fetch('/api/nodes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, title: "New Node", content: "Content here...", buttons: [], x: 500, y: 300 })
    });
    loadNodes();
}

// Global Window Hooks
window.showTab = showTab;
window.closeEditor = closeEditor;
window.saveNode = saveNode;
window.createNewNode = createNewNode;
window.onStartConnect = onStartConnect;
window.onDropPort = onDropPort;
window.addButton = addButton;
window.removeBtn = removeBtn;
window.updateBtnText = updateBtnText;
window.updateBtnLink = updateBtnLink;

// Init
showTab('overview');
setInterval(updateDashboard, 5000);

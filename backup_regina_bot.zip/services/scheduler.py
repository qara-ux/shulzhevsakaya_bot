from apscheduler.schedulers.asyncio import AsyncIOScheduler
from aiogram import Bot
from datetime import datetime, timedelta
from typing import Dict, Any

scheduler = AsyncIOScheduler()

async def send_reminder_no_email(bot: Bot, chat_id: int):
    try:
        await bot.send_message(
            chat_id,
            "Ты не завершила регистрацию 👇\nЗакрепить за тобой место?"
        )
    except Exception as e:
        print(f"Failed to send reminder to {chat_id}: {e}")

async def send_reminder_no_payment(bot: Bot, chat_id: int):
    try:
        await bot.send_message(
            chat_id,
            "Ты почти в марафоне 👇\nМеста ограничены"
        )
    except Exception as e:
        print(f"Failed to send reminder to {chat_id}: {e}")

def schedule_email_reminder(bot: Bot, chat_id: int):
    job_id = f"email_rem_{chat_id}"
    # Remove existing if any
    if scheduler.get_job(job_id):
        scheduler.remove_job(job_id)
        
    scheduler.add_job(
        send_reminder_no_email,
        "date",
        run_date=datetime.now() + timedelta(minutes=15),
        args=[bot, chat_id],
        id=job_id
    )

def schedule_payment_reminder(bot: Bot, chat_id: int):
    job_id = f"pay_rem_{chat_id}"
    # Remove existing if any
    if scheduler.get_job(job_id):
        scheduler.remove_job(job_id)
        
    scheduler.add_job(
        send_reminder_no_payment,
        "date",
        run_date=datetime.now() + timedelta(hours=3),
        args=[bot, chat_id],
        id=job_id
    )

def cancel_reminders(chat_id: int):
    for prefix in ["email_rem_", "pay_rem_"]:
        job_id = f"{prefix}{chat_id}"
        if scheduler.get_job(job_id):
            scheduler.remove_job(job_id)

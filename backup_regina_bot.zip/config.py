from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import SecretStr

class Settings(BaseSettings):
    bot_token: SecretStr
    admin_id: int
    
    # Analytics Dashboard settings
    analytics_api_url: str = "http://localhost:8000"
    analytics_api_key: str = "changeme"
    payment_token: str = "" # Provide via .env
    
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra='ignore')

config = Settings()

from aiogram import Router, F, Bot
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from keyboards.builders import get_start_kb, get_join_kb
from states.marathon import MarathonState
from services.analytics import track_event

router = Router()

@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    await track_event(message.from_user.id, "bot_start", message.from_user.username)
    
    msg_text = (
        "🌸 Весенний марафон «МЕТОД»\n\n"
        "Старт — 11 мая\n"
        "Формат — онлайн\n"
        "4 недели трансформации\n\n"
        "Готова присоединиться?"
    )
    await message.answer(msg_text, reply_markup=get_start_kb())
    await state.set_state(MarathonState.waiting_for_join_decision)

@router.callback_query(F.data == "join_marathon")
async def process_join(callback: CallbackQuery, state: FSMContext):
    await track_event(callback.from_user.id, "click_join", callback.from_user.username)
    await callback.answer()
    
    msg_text = (
        "Отлично 👇\n\n"
        "Стоимость участия:\n"
        "5000₽ (65$)\n\n"
        "Доступ открывается сразу после оплаты\n\n"
        "Дополнительно (короткий блок):\n\n"
        "— тренировки каждый день\n"
        "— питание\n"
        "— поддержка\n\n"
        "Ты просто следуешь системе"
    )
    
    await callback.message.answer(msg_text, reply_markup=get_join_kb())
    await track_event(callback.from_user.id, "price_viewed", callback.from_user.username)

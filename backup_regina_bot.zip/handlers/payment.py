from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, LabeledPrice, PreCheckoutQuery
from aiogram.fsm.context import FSMContext
from aiogram.utils.keyboard import InlineKeyboardBuilder

from states.marathon import MarathonState
from utils.validators import is_valid_email
from services.analytics import track_event
from services.scheduler import schedule_email_reminder, schedule_payment_reminder, cancel_reminders
from config import config

router = Router()

@router.callback_query(F.data == "go_to_payment")
async def ask_email(callback: CallbackQuery, state: FSMContext, bot: Bot):
    await track_event(callback.from_user.id, "click_pay", callback.from_user.username)
    await callback.answer()
    await callback.message.answer("Куда отправить доступ?\n\nВведи свой email:")
    await state.set_state(MarathonState.waiting_for_email)
    schedule_email_reminder(bot, callback.from_user.id)

@router.message(MarathonState.waiting_for_email)
async def process_email(message: Message, state: FSMContext, bot: Bot):
    email = message.text.strip()
    if not is_valid_email(email):
        await message.answer("❌ Ошибка в формате почты.\n\nПожалуйста, введи корректный email (например: alex@gmail.com):")
        return

    await track_event(message.from_user.id, "contact_submitted", message.from_user.username, email=email)
    await state.update_data(email=email)
    cancel_reminders(message.from_user.id)
    
    # Send Fake Payment Button
    builder = InlineKeyboardBuilder()
    builder.button(text="💳 Оплатить 5000₽ (ТЕСТ)", callback_data="check_payment_stub")
    
    await message.answer(
        "Спасибо! Теперь переходи к оплате.\n\n"
        "*(Это тестовый режим: просто нажмите кнопку ниже для имитации покупки)*",
        reply_markup=builder.as_markup()
    )
    
    await state.set_state(MarathonState.waiting_for_payment)
    await track_event(message.from_user.id, "payment_started", message.from_user.username)
    schedule_payment_reminder(bot, message.from_user.id)

from handlers.dynamic import send_node

@router.callback_query(F.data == "check_payment_stub")
async def check_payment_mock(callback: CallbackQuery, state: FSMContext, bot: Bot):
    await track_event(callback.from_user.id, "payment_success", callback.from_user.username, amount=5000)
    
    # Mark as paid in DB
    await fetch_from_api(f"/api/users/{callback.from_user.id}/pay", method="POST")
    cancel_reminders(callback.from_user.id)
    
    # Use the dynamic system to send the success node from DB
    await state.clear()
    await send_node(callback, "success", state)

@router.pre_checkout_query()
async def process_pre_checkout(pre_checkout_query: PreCheckoutQuery):
    await pre_checkout_query.answer(ok=True)

@router.message(F.successful_payment)
async def process_successful_payment(message: Message, state: FSMContext, bot: Bot):
    await track_event(message.from_user.id, "payment_success", message.from_user.username, amount=5000)
    await fetch_from_api(f"/api/users/{message.from_user.id}/pay", method="POST")
    cancel_reminders(message.from_user.id)
    
    # Use the dynamic system to send the success node from DB
    await state.clear()
    await send_node(message, "success", state)

async def fetch_from_api(path, method="GET"):
    import aiohttp
    async with aiohttp.ClientSession() as session:
        async with session.request(method, f"{config.analytics_api_url}{path}") as resp:
            return await resp.json()
